function Home() {
  document.title = 'Your Project - Home'
  return (
    <div className="Home">
      Home
    </div>
  )
}
